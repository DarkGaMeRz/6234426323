package lab9_2;

public class Expo extends Taylor {
    
    public Expo(int k, double x) {
        super(k, x);
    }
    
    @Override
    public double getApprox() {
        double total = 0;
        for (int i = 0; i<= getIter(); i++) {
            total = total + Math.pow(getValue(), i) / factorial(i);
        }
        return total;
    }
    
    @Override
    public void printValue() {
        System.out.println("Value from Math.exp() is " + Math.exp(getValue()) + "\nApproximated value is "
        + getApprox());
    }
}
