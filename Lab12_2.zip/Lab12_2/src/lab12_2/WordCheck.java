package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WordCheck {
    public static void main(String[] args) {
        try {
            Scanner input = new Scanner(System.in);
            File file = new File("wordlist.txt");
            String sentence, notContain = "";
            System.out.print("Enter a sentence : ");
            sentence = input.nextLine();
            String[] word = sentence.split("\\s+");
            for(String w : word) {
                Scanner wL = new Scanner(file);
                boolean bool = true;
                
                while(wL.hasNextLine()) {              
                    String wordIn = wL.nextLine();
                    if(wordIn.contains(w)) {
                        bool = false;
                        break;
                    }
                }
                
                if(bool) {
                    notContain += w+" ";
                }
            }
            
            if(notContain.equals("")) {
                notContain = "N/A";
            }
            
            System.out.println("Words not contained : \n"+notContain);
            input.close();
        }
        
        catch(FileNotFoundException e) {
            System.out.println(e);
        }
    }
}