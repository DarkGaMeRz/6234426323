package lab3_1;

public class InsectPopulation {
    private double population, insect;
    
    public InsectPopulation(double amount) {
            insect = amount;
    }
        
    public void breed(){
        insect =  ((insect)*2);
    }
    
    public void spray(){
        insect = ((insect*90)/100);
    }
    
    public double getNumInsect(){
        return insect;
    }
}
