package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {
    private ArrayList<String> music;
    
    public MusicBox() {
        music = new ArrayList<>();
    }
    
    @Override
    public void enqueue(Object o) {
        music.add((String) o);
        System.out.println(o+" is added in queue");
    }
    
    @Override
    public void dequeue() {
        System.out.println("Now playing " + music.get(0));
        music.remove(0);
    }
}
