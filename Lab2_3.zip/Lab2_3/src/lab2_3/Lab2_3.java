/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 *
 * @author usci
 */
public class Lab2_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        GregorianCalendar today = new GregorianCalendar(2020, Calendar.JANUARY, 20);
        GregorianCalendar myBirthday = new GregorianCalendar(2000, Calendar.SEPTEMBER, 26);
        today.add(Calendar.DAY_OF_MONTH, 100);
        myBirthday.add(Calendar.DAY_OF_MONTH, 10000);
        int dayOfMonth1 = today.get(Calendar.DAY_OF_MONTH);
        int month1 = today.get(Calendar.MONTH)+1;
        int year1 = today.get(Calendar.YEAR);
        int weekday1 = today.get(Calendar.DAY_OF_WEEK);
        int dayOfMonth2 = myBirthday.get(Calendar.DAY_OF_MONTH);
        int month2 = myBirthday.get(Calendar.MONTH)+1;
        int year2 = myBirthday.get(Calendar.YEAR);
        int weekday2 = myBirthday.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday1+" "+dayOfMonth1+" "+month1+" "+year1);
        System.out.println(weekday2+" "+dayOfMonth2+" "+month2+" "+year2);
    }
    
}
