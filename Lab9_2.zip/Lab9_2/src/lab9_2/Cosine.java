package lab9_2;

public class Cosine extends Taylor {
    
    public Cosine(int k, double x) {
        super(k, x);
    }
    
    @Override
    public double getApprox() {
        double total = 0;
        for (int i = 0; i<= getIter(); i++) {
            total = total + Math.pow(-1, i) * Math.pow(getValue(), 2*i) / factorial(2*i);
        }
        return total;
    }
    
    @Override
    public void printValue() {
        System.out.println("Value from Math.cos() is " + Math.cos(getValue()) + "\nApproximated value is "
        + getApprox());
    }
}
