package lab10_1;

interface Evaluation {
    double evaluate();
    char grade(double x);
}