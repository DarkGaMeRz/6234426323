package lab3_1;


public class InsectPopulationTester {
    
    public static void main(String[] args){
        InsectPopulation popInsect = new InsectPopulation(10);

        popInsect.breed();
        popInsect.spray();
        System.out.println("Number of insects: "+popInsect.getNumInsect());

        popInsect.breed();
        popInsect.spray();
        System.out.println("Number of insects: "+popInsect.getNumInsect());

        popInsect.breed();
        popInsect.spray();
        System.out.println("Number of insects: "+popInsect.getNumInsect());
    }
}