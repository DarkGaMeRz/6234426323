package lab10_2;

import java.util.ArrayList;

public class BusTester {
    public static void main(String[] args) {
        ArrayList<Bus> arr = new  ArrayList<Bus>();
        arr.add(new Hybrid(45,1.2,600,150,1));
        arr.add(new CNGBus(50,1,200,2));
        
        for(Bus i : arr) {
           if(i instanceof CNGBus) {
               CNGBus j = (CNGBus) i;
               System.out.println("ID: "+i.getID()+
                       "\nEmission Tier: "+j.getEmissionTier()+
                       "\nAccel: "+i.getAccel());
           }
           else if(i instanceof Hybrid) {
               Hybrid j = (Hybrid) i;
               System.out.println("ID: "+i.getID()+
                       "\nEmission Tier: "+j.getEmissionTier()+
                       "\nAccel: "+i.getAccel());
           }
           else {
                System.out.println("ID: "+i.getID()+"\nAccel: "+i.getAccel());
           }
       }
    }
}
