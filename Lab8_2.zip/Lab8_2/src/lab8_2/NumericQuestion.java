package lab8_2;

public class NumericQuestion extends Question {
    
    public NumericQuestion(String text) {
        super(text);
    }
    
    public boolean checkAnswer(String response) {
        if (Math.abs(Double.valueOf(response)-Double.valueOf(getAnswer()))<0.01) {
            return true;
        }
        return false;
    }
}
