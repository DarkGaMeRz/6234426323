package lab4_1;

public class SodaCan {
    private float d,r,h,V,A;
    
    public SodaCan(float height, float diameter) {
        d = diameter;
        h = height;
        r = diameter/2;
    }
    
    public float getVolume() {
        V =(float) ((Math.PI)*(Math.pow(r, 2))*h);
        return V;
    }
    
    public float getSurfaceAre() {
        A = (float) (2*(Math.PI)*(Math.pow(r, 2))+2*(Math.PI)*r*h);
        return A;
    }
}
