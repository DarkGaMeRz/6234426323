package lab12_3;

public class TransactionRecord {
    private int accNum;
    private double amount;
    
    public TransactionRecord(int accNum, double amount) {
        this.accNum = accNum;
        this.amount = amount;
    }
    
    public int getAccNum() {
        return accNum;
    }
    
    public double getAmount() {
        return amount;
    }
}
