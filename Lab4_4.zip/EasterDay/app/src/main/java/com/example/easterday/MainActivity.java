package com.example.easterday;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    int y;
    String month;
    static String easterDay;

    EditText yearInput;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        yearInput = findViewById(R.id.yearInput);

        button = findViewById((R.id.button));

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                y = Integer.valueOf(yearInput.getText().toString());

                int a = y % 19;
                int b = y / 100;
                int c = y % 100;
                int d = b / 4;
                int e = b % 4;
                int g = (8 * b + 13) / 25;
                int h = (19 * a + b - d - g + 15) % 30;
                int j = c / 4;
                int k = c % 4;
                int m = (a + 11 * h) / 319;
                int r = (2 * e + 2 * j - k - h + m +32) % 7;
                int n = (h - m + r + 90) / 25;
                int p = (h - m + r + n + 19) % 32;

                if (n == 3)
                    month = "March";
                else if (n == 4)
                    month = "April";

                easterDay = month + " " + p;

                goToSecondActivity();
            }
        });
    }

    private void goToSecondActivity() {
        Intent intent = new Intent(this, NextActivity.class);
        startActivity(intent);
    }
}