package lab8_1;

public class Car {
    double gas;
    double efficiency;
    
    public Car(double gas, double efficiency) {
        this.gas = gas;
        this.efficiency = efficiency;
    }
    
    public void drive(double distance) {
        double usedGas = distance/efficiency;
        if(usedGas > gas) {
            System.out.println("You cannot drive too far, please add gas");
        }
        else {
            gas = gas-usedGas;
        }
    }
    
    public void setGas(double amount) {
        gas = amount;
    }
    
    public double getGas() {
        return gas;
    }
    
    public double getEfficiency() {
        return efficiency;
    }
    
    public void addGas(double amount) {
        gas = gas+amount;
    }
}
