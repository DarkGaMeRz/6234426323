package lab8_1;

public class Truck extends Car {
    private double M_weight;
    private double weight;
    
    public Truck(double gas, double efficiency, double M_weight, double weight) {
        super(gas, efficiency);
        if(weight>M_weight) {
            weight=M_weight;
        }
        this.weight=weight;
        this.M_weight=M_weight;
    }
    
    @Override
    public void drive(double distance) {
        double usedGas = distance/efficiency;
        if(weight<1) {
            usedGas = usedGas;
        }
        if(1<=weight &&  weight<=10) {
            usedGas = usedGas*110/100;
        }
        if(10<weight &&  weight<=20) {
            usedGas = usedGas*120/100;
        }
        if(weight>20) {
            usedGas = usedGas*130/100;
        }
        if(usedGas>gas) {
            System.out.println("You cannot drive too far, please add gas");
        }
        else {
            gas = gas-usedGas;
        }
    }
}