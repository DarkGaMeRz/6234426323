package lab7_2;

public class MagicSquareTester {
    public static void main(String[] args) {
        MagicSquare ms = new MagicSquare(7);
        System.out.println(ms.toString());
    }
    
}
