package lab4_3;

public class TimeInterval {
    private int hourS, minS, hourE, minE, hour, min, fin;
    
    public TimeInterval(int start, int end) {
        hourS = start/100*60;
        minS = start%100+hourS;
        hourE = end/100*60;
        minE = end%100+hourE;
        fin = Math.abs(minE-minS+1440)%1440;
    }
    
    public int getHours() {
        hour = fin/60;
        return hour;
    }
    
    public int getMinutes() {
        min = fin%60;
        return min;
    }
    
}
