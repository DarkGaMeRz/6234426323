package lab3_3;

public class CashRegister {
    private double total,payment,totalTax,tax,good,fee;
    
    public CashRegister(double constructor) {
        fee = constructor;
    }
    
    public void recordTaxablePurchase(double taxGood) {
        tax = (taxGood*fee)+tax;
        good = taxGood;
    }
    
    public void getTotalTax() {
        totalTax = good+tax;
    }
    
    public void recordPurchase(double price) {
        total = total + price;
    }
    
    public void enterPayment(double cash) {
        payment = payment + cash;
    }
    
    public double giveChange() {
        double change = (float) (payment - total - totalTax);
        total = 0;
        payment = 0;
        totalTax = 0;
        tax = 0;
        good = 0;
        return change;
    }
}

