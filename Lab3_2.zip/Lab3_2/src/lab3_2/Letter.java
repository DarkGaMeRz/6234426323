package lab3_2;

public class Letter {
    private String text,a,b,finText;
    
    public Letter(String A, String B) {
        a = A;
        b = B;
        text = "";
    }
    
    public void addLine(String typeText) {
        text = text + "\n" + typeText;
    }
    
    public String getText() {
        finText = "Dear " + a + ":" + "\n" + text + "\n\n" + "Sincerely," + "\n\n" + b;
        return finText;
    }
}
