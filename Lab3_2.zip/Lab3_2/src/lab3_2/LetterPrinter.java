package lab3_2;

public class LetterPrinter {
    
    public static void main(String[] args) {
        Letter mes = new Letter("Jade","Clarissa");
        mes.addLine("We must find Simon quickly.");
        mes.addLine("He might be in danger.");
        System.out.println(mes.getText());
    }
}