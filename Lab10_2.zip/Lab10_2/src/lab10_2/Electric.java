package lab10_2;

public interface Electric {
    static double LOW_VOLTAGE = 480;
    static double HIGH_VOLTAGE = 600;
    double getVoltage();
}
