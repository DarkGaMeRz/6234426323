package lab9_1;

import java.util.ArrayList;

public class Order {
    public static int cntOrder = 0;
    private int id;
    private Customer c;
    private ArrayList<Pizza> p;
    
    public Order(Customer c) {
        this.c = c;
        p = new ArrayList<Pizza>();
        cntOrder++;
        id = cntOrder;
    }
    
    public void addPizza(Pizza a) {
        p.add(a);
    }
    
    public String getOrderDetail() {
        String text =  "Order id : " + id + "\n" + c.getName() + " tel : " + c.getTel();
        
        if (c instanceof GoldCustomer) {
            GoldCustomer gC = (GoldCustomer) c;
            text = text + " discount : " + gC.getDiscount() + "\n";
        }
        else {
            text = text + "\n";
        }
        
        for (Pizza pizza : p) {
            if (pizza instanceof PizzaSpecial) {
                PizzaSpecial pS = (PizzaSpecial) pizza;
                text = text + pS.getName() + " price : " + pS.getPrice() + " special : " + pS.getSpecial() + "\n";
            }
            else {
                text = text + pizza.getName() + " price : " + pizza.getPrice() + "\n";
            }
        }
        
        text = text + "Total pieces : " + p.size() + "\n" + "Total cost : " + calculatePayment();
        return text;
    }
    
    public double calculatePayment() {
        double total = 0;
        if (c instanceof GoldCustomer) {
            GoldCustomer gC = (GoldCustomer) c;
            for (Pizza pizza : p) {
                total = total + pizza.getPrice() - pizza.getPrice() * gC.getDiscount() / 100;
            }
        }
        else {
            for (Pizza pizza : p) {
                total = total + pizza.getPrice();
            }
        }
        return total;
    }
}
