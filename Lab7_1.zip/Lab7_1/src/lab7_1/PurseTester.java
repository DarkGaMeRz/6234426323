package lab7_1;

public class PurseTester {
    public static void main(String[] args) {
        Purse purseA = new Purse();
        purseA.addCoin("Nickel");
        purseA.addCoin("Quater");
        purseA.addCoin("Nickel");
        purseA.addCoin("Dime");
        System.out.println("purseA : " + purseA.toString());
        
        Purse purseB = new Purse();
        purseB.addCoin("Quater");
        purseB.addCoin("Dime");
        purseB.addCoin("Nickel");
        purseB.addCoin("Nickel");
        System.out.println("purseB : " + purseB.toString());
        
        System.out.println("---purseB reverse---");
        purseB.reverse();
        System.out.println("purseB : " + purseB.toString());
        
        System.out.println("Same coins : " + purseA.sameCoins(purseB));
        System.out.println("Same content : " + purseA.sameContents(purseB));
        
        purseA.transfer(purseB);
        System.out.println("---Transfer---");
        System.out.println("purseA : " + purseA.toString());
        System.out.println("purseB : " + purseB.toString());
        System.out.println("Same coins : " + purseA.sameCoins(purseB));
        System.out.println("Same content : " + purseA.sameContents(purseB));
        
        Purse purseC = new Purse();
        Purse purseD = new Purse();
        purseD.addCoin("Quater");
        purseD.addCoin("Dime");
        purseD.addCoin("Dime");
        purseD.addCoin("Nickel");
        System.out.println("purseC : " + purseC.toString());
        System.out.println("purseD : " + purseD.toString());
        System.out.println("Same coins : " + purseC.sameCoins(purseD));
        System.out.println("Same content : " + purseC.sameContents(purseD));
        
        purseC.addCoin("Dime");
        System.out.println("Same coins : " + purseC.sameCoins(purseD));
        System.out.println("Same content : " + purseC.sameContents(purseD));
    }
}
