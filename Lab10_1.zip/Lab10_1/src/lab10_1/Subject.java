package lab10_1;

public class Subject implements Evaluation {
    private String subjName;
    private int[] score;
    
    public Subject(String subjName, int[] score) {
        this.subjName = subjName;
        this.score = score;
    }
    
    @Override
    public double evaluate() {
        double sum = 0.0;
        for(int i : score)
            sum+=i;
        double ave=sum/score.length;
        return ave;
    }
    
    @Override
    public char grade(double evaluate) {
        if(evaluate>=70) {
            return 'P';
        }
        return 'F';
    }
    
    @Override 
    public String toString(){
            return this.subjName;
    }
}
