package lab7_1;

import java.util.ArrayList;

public class Purse {
    
    private ArrayList purse;
    private ArrayList purseA;
    private ArrayList check;
    
    public Purse() {
        purse = new ArrayList<String>();
        purseA = new ArrayList<String>();
    }
    
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    
    @Override
    public String toString(){
        if (purse.isEmpty()){ 
            return "Purse[]"; 
        }
        String output = "Purse[";
        for (Object coin : purse){
            output = output + coin + ",";
        }
        output = output.substring(0, output.length() - 1);
        return output + "]";
    }
    
    public ArrayList<String> reverse(){
        for(int i=purse.size()-1; i>=0; i--){
           purseA.add((String) purse.get(i));
        }
        purse = purseA;
        return purse;
    }

    public void transfer(Purse other){
        for(Object coin : this.purse){
            other.purse.add(coin);
        }
        this.purse.clear();  
    }
    
    public boolean sameContents(Purse other){
        boolean tF = true;
        if(purse.size() == other.purse.size()){
            for(int i=0; i<purse.size(); i++){
                tF = purse.get(i).equals(other.purse.get(i));
            }
        }
        else {
            tF = false; 
        }
        return tF;
    }
    
    public boolean sameCoins(Purse other){
        check = (ArrayList) other.purse.clone();
        boolean tF = true;
        if(purse.size() == other.purse.size()){
            for(int i=0; i<purse.size(); i++){
                boolean remove = false;
                for(int j=0; j<check.size() && !remove;j++){
                    if (purse.get(i) == check.get(j)){
                        check.remove(j);
                        remove = true;
                    }
                }
                if(!remove) {
                    tF=false;
                }
            }
        }
        else {
            tF = false; 
        }
        return tF;
    }
}
