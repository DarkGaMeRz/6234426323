package lab6_2;

import java.util.Random;
import java.util.Scanner;

public class Game {
    private int comSc;
    private int userSc;
    
    public void Game() {
        comSc = 0;
        userSc = 0;
    }
    
    public void play() {
        while(true) {
            Scanner rPS = new Scanner(System.in);
            System.out.print("Enter 0 for ROCK, 1 for PAPER, 2 for SCISSORS: ");
            String userChoose = rPS.next();
            if ("0".equals(userChoose)) {
                System.out.println("You enter: ROCK");
            }
            else if ("1".equals(userChoose)) {
                System.out.println("You enter: PAPER");
            }
            else if ("2".equals(userChoose)) {
                System.out.println("You enter: SCISSORS");
            }
            else {
                continue;
            }
            Random comPlay = new Random();
            int comChoose = comPlay.nextInt(2);
            if (comChoose==0) {
                System.out.println("Computer: ROCK");
            }
            if (comChoose==1) {
                System.out.println("Computer: PAPER");
            }
            if (comChoose==2) {
                System.out.println("Computer: SCISSORS");
            }
            int choose = Integer.parseInt(userChoose);
            if ((choose == 0 && comChoose == 2) || (choose == 1 && comChoose == 0) || (choose == 2 && comChoose == 1)) {
                System.out.println("You win!");
                userSc+=1;
            }
            if ((choose == 0 && comChoose == 0) || (choose == 1 && comChoose == 1) || (choose == 2 && comChoose == 2)) {
                System.out.println("It's a tie.");
            }
            if ((choose == 0 && comChoose == 1) || (choose == 1 && comChoose == 2) || (choose == 2 && comChoose == 0)) {
                System.out.println("You lose!");
                comSc+=1;
            }
            
            if(comSc-userSc==2) {
                System.out.println("----------------------------------------");
                System.out.println("Too bad! You lose.");
                System.out.println("User Score: "+userSc);
                System.out.println("Computer Score: "+comSc);
                break;
            }
            if(userSc-comSc==2) {
                System.out.println("----------------------------------------");
                System.out.println("Congrats! You win.");
                System.out.println("User Score: "+userSc);
                System.out.println("Computer Score: "+comSc);
                break;
            }
        }
    }   
}