package lab5_1;

import java.util.Scanner;

public class ZellerTester {
    public static void main(String[] args) {
        Scanner date = new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int year = date.nextInt();;
        System.out.print("Enter month (1-12): ");
        int month = date.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int dayOfMonth = date.nextInt();
        Zeller zeller = new Zeller(year, month, dayOfMonth);
        System.out.println("Day of the week is "+zeller.getDayOfWeek());
    }
}
