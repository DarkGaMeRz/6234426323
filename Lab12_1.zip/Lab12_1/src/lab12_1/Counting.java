package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Scanner;

public class Counting {
    public static void main(String[] args) throws FileNotFoundException {
        int wordCount = 0;
        int charCount = 0;
        int lineCount = 0;
        String s = "";
        PrintWriter output = new PrintWriter("wordlenght.txt");
        Scanner lenght = new Scanner(System.in);
        
        while(!s.equals("quit")) {
            s = lenght.nextLine();
            if(!s.equals("quit")) {
                output.println(s);
            }
        } 
        
        output.close();
        File file = new File("wordlenght.txt");
        Scanner cnt = new Scanner(file);
        
        while(cnt.hasNextLine()) {
                    lineCount +=1;
                    s = cnt.nextLine();
                    charCount += s.length();
                    String[] n = s.split("\\s+");
                    wordCount += n.length;
        }
        
        System.out.println("Total characters : "+charCount); 
        System.out.println("Total words : "+wordCount);
        System.out.println("Total lines : "+lineCount);
        cnt.close();
    }
    
}
