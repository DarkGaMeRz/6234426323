package lab4_1;

import java.util.Scanner;

public class SodaTester {
        
    public static void main(String[] args) {
        
        Scanner hT = new Scanner(System.in);
        System.out.print("Enter height: ");
        float hS = hT.nextInt();
        Scanner dT = new Scanner(System.in);
        System.out.print("Enter diametert: ");
        float dS = dT.nextInt();
        SodaCan vA = new SodaCan(hS, dS);
        System.out.println("Volume: "+String.format("%.2f", vA.getVolume())+"\n"+"Surface Area: "+String.format("%.2f", vA.getSurfaceAre()));
    }
    
}
