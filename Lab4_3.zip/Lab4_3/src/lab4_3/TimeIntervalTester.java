package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {
    
    public static void main(String[] args) {
        Scanner test1 = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int time1 = test1.nextInt();
        Scanner test2 = new Scanner(System.in);
        System.out.print("Enter end time: ");
        int time2 = test2.nextInt();
        TimeInterval hM = new TimeInterval(time1, time2);
        System.out.println(hM.getHours()+" hours "+hM.getMinutes()+" minutes");
    }
    
    
}
