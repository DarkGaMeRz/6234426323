package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        try( RandomAccessFile opfile = new RandomAccessFile("newMaster.dat","rw");){
            ArrayList <AccountRecord> accData = new ArrayList<>();
            ArrayList <TransactionRecord> transData = new ArrayList<>();
            File file1 = new File("master.txt");
            File file2 = new File("trans.txt ");
            Scanner input1 = new Scanner(file1);
            Scanner input2 = new Scanner(file2);
            
            while(input1.hasNextLine() && input1.hasNext()) {
                int s1 = Integer.parseInt(input1.next());
                String s2 = input1.next();
                String s3 = input1.next();
                double s4 = Double.parseDouble(input1.next());
                AccountRecord acc = new  AccountRecord(s1,s2+" "+s3,s4);
                accData.add(acc);
            }
            
            while(input2.hasNextLine()&&input2.hasNext()) {
                int s1 = input2.nextInt();
                double s2 = input2.nextDouble();
                TransactionRecord trans = new TransactionRecord(s1,s2);
                transData.add(trans);
            }
            
            accData.forEach((acc) -> {
                transData.stream().filter((trns) -> (acc.getAcctNo()==trns.getAccNum())).forEachOrdered((trns) -> {
                     acc.combine(trns);
                });
            });
            
            for(AccountRecord acc: accData) {
                String s = acc.getName();
                for(int i = 1;i<=30-acc.getName().length();i++) {
                    s+=" ";
                }
                opfile.writeInt(acc.getAcctNo());
                opfile.writeChars(s);
                opfile.writeDouble(acc.getBalance());
                opfile.writeInt(acc.getTransCnt());
            }
            
            double sumBl = 0;
            int noTrans = 0;
            int totalAcc = 0;
            
            for(int i=0;i<opfile.length();i+=76) {
                totalAcc ++;
                opfile.seek(i+64);
                sumBl += opfile.readDouble();
                if(opfile.readInt()==0) {
                    noTrans++;
                }
            }
            
            if (noTrans==1) {
                System.out.println("Total Account Record : "+totalAcc+"\nTotal balance : "+sumBl+"\nNo transaction : "+noTrans+" account." );
            }
            else {
                System.out.println("Total Account Record : "+totalAcc+"\nTotal balance : "+sumBl+"\nNo transaction : "+noTrans+" accounts." );
            }
            
            opfile.close();
        }
        
        catch(IOException e) {
            System.out.println(e);
        }
    }
}
