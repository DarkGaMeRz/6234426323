package lab3_3;

public class CashRegisterTester {
    public static void main(String[] args) {
        CashRegister change = new CashRegister(0.07);
        change.recordTaxablePurchase(20);
        change.getTotalTax();
        change.recordPurchase(50);
        change.recordPurchase(10);
        change.enterPayment(100);
        System.out.printf("Your change is "+"%.1f\n",change.giveChange());
    }
}
