package lab4_2;

public class DigitExtractor {
    private int digit, num;
    public int i=1;
    
    public DigitExtractor(int anInteger) {
        num = anInteger;
    }
    
    public int nextDigit() {
        digit = (int) ((num%Math.pow(10, i))/(Math.pow(10, i-1)));
        i+=1;
        return digit;
    }
    
}
